package com.example.myapplication;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.util.Log;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.concurrent.Executor;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends AppCompatActivity {

    final String WHAT_KEY = "what_key";
    final String PROGRESS_STATUS = "prog_stat";
    final String NUM_KEY = "Num_Key";
    final String AVG_KEY = "avg_Key";
    final String PROGRESS_KEY = "prog_key";

    TextView progress;
    TextView average;
    SeekBar seekBar;
    TextView prog;
    TextView avgNum;
    ExecutorService threadpool;
    int times;
    Handler handler;
    ArrayList<String> number = new ArrayList<>();
    ListView listView;
    ArrayAdapter<String> adapter;


   @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        average = findViewById(R.id.textView2);
        progress = findViewById(R.id.textView3);
        prog = findViewById(R.id.textView4);
        prog.setText(getString(R.string.zero));
        seekBar = findViewById(R.id.seekBar);
        avgNum = findViewById(R.id.textView7);
        avgNum.setText("");
        seekBar.setMax(20);
        seekBar.setProgress(0);
        threadpool = Executors.newFixedThreadPool(2);
        ProgressBar progressBar = findViewById(R.id.progressBar);
        progressBar.setMax(20);
        listView = findViewById(R.id.listview);
        adapter = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, android.R.id.text1, number);
        listView.setAdapter(adapter);



        seekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int i, boolean b) {
                progress.setText(i+" "+ getString(R.string.times));
                progressBar.setMax(i);
                times = i;
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {

            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {


            }
        });





        findViewById(R.id.button).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (times == 0){

                    Toast.makeText(getApplicationContext(),getString(R.string.msg) , Toast.LENGTH_SHORT).show();


                }else{


                    findViewById(R.id.button).setEnabled(false);
                    seekBar.setEnabled(false);
                    number.clear();
                    avgNum.setText("");
                    progressBar.setProgress(0);
                    prog.setText(getString(R.string.zero));
                    adapter.notifyDataSetChanged();
                    findViewById(R.id.toHide).setVisibility(view.VISIBLE);

                    threadpool.execute(new Runnable() {
                        @Override
                        public void run() {
                            double sum = 0;
                            for (int i = 0; i < times; i++) {
                                double num = HeavyWork.getNumber();
                                sum = num+ sum;
                                Message msg = new Message();
                                Bundle bundle = new Bundle();
                                bundle.putString(WHAT_KEY, PROGRESS_STATUS);
                                bundle.putDouble(NUM_KEY, num);
                                bundle.putDouble(AVG_KEY, ((double) sum)/((double) (i+1)));
                                bundle.putDouble(PROGRESS_KEY, i+1);
                                msg.setData(bundle);
                                handler.sendMessage(msg);

                            }




                        }
                    });


                }


            }
        });

        handler = new Handler(new Handler.Callback() {
            @Override
            public boolean handleMessage(@NonNull Message message) {

                Bundle bundle = message.getData();

                String status = bundle.getString(WHAT_KEY);

                double num = bundle.getDouble(NUM_KEY);
                double avg = bundle.getDouble(AVG_KEY);
                int progress = (int)bundle.getDouble(PROGRESS_KEY);


                progressBar.setProgress(progress);
                prog.setText(progress + "/" +times);

                number.add(String.valueOf(num));

                if(progress == times){
                    findViewById(R.id.button).setEnabled(true);
                    seekBar.setEnabled(true);
                }

                adapter.notifyDataSetChanged();



                avgNum.setText(avg+"");


                return false;
            }
        });


    }



}
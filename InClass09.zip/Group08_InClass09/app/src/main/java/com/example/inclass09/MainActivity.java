/*
 Assignment: InClass09
 File Name: MainActivity.java
 Group Number 08
 Full Name:
 Arihant Bhat
 Akash Nevatia
*/

package com.example.inclass09;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;
import androidx.room.Room;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity implements GradeFinalPageFragment.GradesInterface, AddCourseFragment.AddCourseInterface {

    courseCollectionDatabase db;
    ArrayList<courseCollection> courseCollections;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        db = Room.databaseBuilder(this, courseCollectionDatabase.class, "Grades.db")
                .allowMainThreadQueries()
                .fallbackToDestructiveMigration()
                .build();

        courseCollections = (ArrayList<courseCollection>) db.courseCollectionDao().getAll();

        getSupportFragmentManager().beginTransaction()
                .add(R.id.root, GradeFinalPageFragment.newInstance(courseCollections))
                .commit();
    }

    @Override
    public void addNewCourse(String number, String name, String hours, String grade) {
        getSupportFragmentManager().popBackStack();
        db.courseCollectionDao().insertAll(new courseCollection(number, name, hours, grade));
        courseCollections = (ArrayList<courseCollection>) db.courseCollectionDao().getAll();
        getSupportFragmentManager().beginTransaction()
                .replace(R.id.root, GradeFinalPageFragment.newInstance(courseCollections))
                .commit();
    }

    @Override
    public void cancelNewCourse() {
        courseCollections = (ArrayList<courseCollection>) db.courseCollectionDao().getAll();
        getSupportFragmentManager().popBackStack();
        getSupportFragmentManager().beginTransaction()
                .replace(R.id.root, GradeFinalPageFragment.newInstance(courseCollections))
                .commit();
    }

    @Override
    public void delete(courseCollection course) {
        getSupportFragmentManager().popBackStack();
        db.courseCollectionDao().delete(course);

        courseCollections = (ArrayList<courseCollection>) db.courseCollectionDao().getAll();
        getSupportFragmentManager().beginTransaction()
                .replace(R.id.root, GradeFinalPageFragment.newInstance(courseCollections))
                .commit();
    }

    @Override
    public void goToAddCourse() {
        getSupportFragmentManager().beginTransaction()
                .replace(R.id.root, new AddCourseFragment())
                .addToBackStack(null)
                .commit();
    }
}
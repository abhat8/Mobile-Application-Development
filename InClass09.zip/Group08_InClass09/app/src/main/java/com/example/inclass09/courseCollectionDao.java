package com.example.inclass09;

import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.Query;

import java.util.List;

@Dao
public interface courseCollectionDao {

    @Insert
    void insertAll(courseCollection... courses);

    @Delete
    void delete(courseCollection course);

    @Query("SELECT * from CourseCollectionTable WHERE id = :id")
    courseCollection findByID(long id);

    @Query("SELECT * from CourseCollectionTable")
    List<courseCollection> getAll();
}

package com.example.inclass09;


import androidx.room.Database;
import androidx.room.RoomDatabase;

@Database(entities = {courseCollection.class}, version = 1)
public abstract class courseCollectionDatabase extends RoomDatabase {

    public abstract courseCollectionDao courseCollectionDao();

}

package com.example.inclass09;

import android.content.Context;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;


public class GradeFinalPageFragment extends Fragment implements CourseListAdapter.AdapterInterface {

    LinearLayoutManager layoutManager;
    RecyclerView recyclerViewCourses;
    GradesInterface mListener;
    CourseListAdapter adapter;
    ArrayList<courseCollection> Courseslist;
    TextView textViewGPA, textViewHours;
    private static final String ARG_COURSES = "ARG_COURSES";


    public GradeFinalPageFragment() {
        // Required empty public constructor
    }


    // TODO: Rename and change types and number of parameters
    public static GradeFinalPageFragment newInstance(ArrayList<courseCollection> courses) {
        GradeFinalPageFragment fragment = new GradeFinalPageFragment();
        Bundle args = new Bundle();
        args.putSerializable(ARG_COURSES, courses);
        fragment.setArguments(args);
        return fragment;
    }


    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setHasOptionsMenu(true);
        if (getArguments() != null) {
            Courseslist = (ArrayList<courseCollection>) getArguments().getSerializable(ARG_COURSES);
        }
    }


    @Override
    public void onAttach(@NonNull Context context) {
        super.onAttach(context);
        if (context instanceof GradesInterface) {
            mListener = (GradesInterface) context;
        } else {
            throw new RuntimeException(getContext().toString() + " must implement GradesInterface");
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_grade_final_page, container, false);
//        setHasOptionsMenu(true);
        getActivity().setTitle(getResources().getString(R.string.gradesTitle));

        float hours = 0;
        float totalHours = 0;
        float creditPoints = 0;
        String grade;

        textViewGPA = view.findViewById(R.id.textViewGPA);
        textViewHours = view.findViewById(R.id.textViewHours);

        recyclerViewCourses = view.findViewById(R.id.recyclerViewCourses);
        recyclerViewCourses.setHasFixedSize(true);
        layoutManager = new LinearLayoutManager(getContext());
        recyclerViewCourses.setLayoutManager(layoutManager);

        for (int i = 0; i < Courseslist.size(); i++) {
            courseCollection course = Courseslist.get(i);
            hours = Float.parseFloat((course.getCourseHours()));
            totalHours += hours;
            grade = course.getCourseGrade();
            switch (grade) {
                case "A":
                    creditPoints += 4 * hours;
                    break;
                case "B":
                    creditPoints += 3 * hours;
                    break;
                case "C":
                    creditPoints += 2 * hours;
                    break;
                case "D":
                    creditPoints += hours;
                    break;
                case "F":
                    creditPoints += 0;
                    break;
            }
        }

        if (totalHours == 0) {
            creditPoints = 0;
        } else {
            creditPoints = creditPoints / totalHours;
        }

        if (creditPoints == 0 && totalHours == 0) {
            textViewGPA.setText("-");
            textViewHours.setText("-");
        } else {
            textViewGPA.setText(String.format("%.2f", creditPoints));
            textViewHours.setText(String.valueOf(totalHours));
        }

        if (Courseslist.size() != 0) {
            adapter = new CourseListAdapter(Courseslist, GradeFinalPageFragment.this);
            recyclerViewCourses.setAdapter(adapter);
        }

        return view;
    }

    @Override
    public void deleteCourse(courseCollection course) {
        mListener.delete(course);
    }

    interface GradesInterface {
        void delete(courseCollection course);

        void goToAddCourse();
    }

    @Override
    public void onCreateOptionsMenu(Menu menu, MenuInflater inflater) {
//        super.onCreateOptionsMenu(menu, inflater);
        inflater.inflate(R.menu.actionbar_menu, menu);
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        switch (item.getItemId()) {
            case R.id.addCourse:
                mListener.goToAddCourse();
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }
}

package com.example.tipcalculator;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    //Variables declarations
    EditText edEnterBillAmount;
    RadioGroup perGroup;
    SeekBar customPer;
    TextView seekbarProgress;
    TextView tip;
    TextView tipValue;
    TextView total;
    RadioGroup splitBy;
    TextView totalPerPerson;
    TextView totalValue;
    TextView tp;
    Button clear;
    RadioButton rbTen;
    RadioButton rbFifteenPer;
    RadioButton rbEighteenPer;
    RadioButton rbCustom;
    RadioButton rbOne;
    final String TAG = "demo";
    float m ;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);



        //varibale setting id
        edEnterBillAmount = findViewById(R.id.etEnterBillTotal);
        customPer = findViewById(R.id.seekBar);
        customPer.setMax(50);
        tip = findViewById(R.id.tvTip);
        total = findViewById(R.id.tvTotal);
        totalPerPerson = findViewById(R.id.tvToatlPerPerson);
        clear = findViewById(R.id.btClear);
        perGroup = findViewById(R.id.radioGroup);
        splitBy = findViewById(R.id.radioGroup2);
        seekbarProgress = findViewById(R.id.tvProgressSeekBar);
        rbTen = findViewById(R.id.rbTenPer);
        rbFifteenPer = findViewById(R.id.rbfifteenPer);
        rbEighteenPer = findViewById(R.id.rbEighteenPer);
        rbCustom = findViewById(R.id.rbCustom);
        tipValue = findViewById(R.id.tipValue);
        totalValue = findViewById(R.id.totalValue);
        rbOne = findViewById(R.id.rbOne);
        tp = findViewById(R.id.tp);

        //Creating Intial view
        rbTen.setChecked(true);
        rbOne.setChecked(true);
        customPer.setProgress(40);
        seekbarProgress.setText(getString(R.string.progFourty));
        tipValue.setText(getString(R.string.dollorZero));
        totalValue.setText(getString(R.string.dollorZero));
        tp.setText(getString(R.string.dollorZero));

        //setting Seekbar

        customPer.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int i, boolean b) {

                try {
                    float vari = Float.parseFloat(edEnterBillAmount.getText().toString());
                    seekbarProgress.setText(String.valueOf(i));
                    tipValue.setText(getString(R.string.dollor)+ String.format("%.2f", (vari * i / 100)));
                    totalValue.setText(getString(R.string.dollor)+ String.format("%.2f", (vari + (vari * i / 100))));
                    m = vari + (vari * i / 100);
                    String k = String.format("%.2f", m);
                    tp.setText(getString(R.string.dollor) +k );
                }catch(Exception e){

                    seekbarProgress.setText(String.valueOf(i));

                }

            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {
                rbCustom.setChecked(true);

            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {

            }
        });





        //setting Up Bill Value
        edEnterBillAmount.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void afterTextChanged(Editable editable) {
                try {
                    float vari = Float.parseFloat(edEnterBillAmount.getText().toString());
                    if (vari >0) {
                        int i = perGroup.getCheckedRadioButtonId();
                        if(i == rbTen.getId()){
                            customPer.setProgress(10);
                            tipValue.setText(getString(R.string.dollor)+ String.format("%.2f", (vari * 0.1)));
                            totalValue.setText(getString(R.string.dollor) + String.format("%.2f", (vari + (vari * 0.1))));
                            m = (float) (vari + (vari * 0.1));
                            String k = String.format("%.2f", m);
                            tp.setText(getString(R.string.dollor) +k );

                        }
                        else if(i == rbFifteenPer.getId()) {
                            customPer.setProgress(15);
                            tipValue.setText(getString(R.string.dollor) + String.format("%.2f", (vari * 0.15)));
                            totalValue.setText(getString(R.string.dollor) + String.format("%.2f", (vari + (vari * 0.15))));
                            m = (float) (vari + (vari * 0.15));
                            String k = String.format("%.2f", m);
                            tp.setText(getString(R.string.dollor) +k );
                        }else if(i == rbEighteenPer.getId()){
                            customPer.setProgress(18);
                            tipValue.setText(getString(R.string.dollor) + String.format("%.2f", (vari * 0.18)));
                            totalValue.setText(getString(R.string.dollor) + String.format("%.2f", (vari + (vari * 0.18))));
                            m = (float) (vari + (vari * 0.18));
                            String k = String.format("%.2f", m);
                            tp.setText(getString(R.string.dollor) +k + "");
                        }else if(i == rbCustom.getId()){
                            int prog = customPer.getProgress();
                            tipValue.setText(getString(R.string.dollor) + String.format("%.2f", (vari * prog/100)));
                            totalValue.setText(getString(R.string.dollor) + String.format("%.2f", (vari + (vari * prog/100))));
                            m =  (vari + (vari * prog/100));
                            String k = String.format("%.2f", m);
                            tp.setText(getString(R.string.dollor) +k );
                        }
                    }

                    else{
                        Toast.makeText(MainActivity.this, R.string.enterPositiveVal, Toast.LENGTH_SHORT).show();
                    }
                }catch (Exception e){
                    m = 0;
                    tipValue.setText(getString(R.string.dollorZero));
                    totalValue.setText(getString(R.string.dollorZero));
                    tp.setText(getString(R.string.dollorZero));
                    m = 0;
                }


            }
        });

        //Radio Percent Group Operations

        perGroup.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup radioGroup, int i) {

                try {
                    float vari = Float.parseFloat(edEnterBillAmount.getText().toString());
                    if (vari >0) {
                        //int i = perGroup.getCheckedRadioButtonId();
                        if(i == rbTen.getId()){
                            customPer.setProgress(10);
                            tipValue.setText(getString(R.string.dollor) + String.format("%.2f", (vari * 0.1)));
                            totalValue.setText(getString(R.string.dollor) + String.format("%.2f", (vari + (vari * 0.1))));
                            m = (float) (vari + (vari * 0.1));
                            String k = String.format("%.2f", m);
                            tp.setText(getString(R.string.dollor) +k );

                        }
                        else if(i == rbFifteenPer.getId()) {
                            customPer.setProgress(15);
                            tipValue.setText(getString(R.string.dollor)+ String.format("%.2f", (vari * 0.15)));
                            totalValue.setText(getString(R.string.dollor) + String.format("%.2f", (vari + (vari * 0.15))));
                            m = (float) (vari + (vari * 0.15));
                            String k = String.format("%.2f", m);
                            tp.setText(getString(R.string.dollor) +k );
                        }else if(i == rbEighteenPer.getId()){
                            customPer.setProgress(18);
                            tipValue.setText(getString(R.string.dollor) + String.format("%.2f", (vari * 0.18)));
                            totalValue.setText(getString(R.string.dollor) + String.format("%.2f", (vari + (vari * 0.18))));
                            m = (float) (vari + (vari * 0.18));
                            String k = String.format("%.2f", m);
                            tp.setText(getString(R.string.dollor) +k );
                        }else if(i == rbCustom.getId()){
                            int prog = customPer.getProgress();
                            tipValue.setText(getString(R.string.dollor) + String.format("%.2f", (vari * prog/100)));
                            totalValue.setText(getString(R.string.dollor) + String.format("%.2f", (vari + (vari * prog/100))));
                            m = vari + (vari * prog/100);
                            String k = String.format("%.2f", m);
                            tp.setText(getString(R.string.dollor) +k );
                        }
                    }

                    else{
                        Toast.makeText(MainActivity.this, R.string.enterPositiveVal, Toast.LENGTH_SHORT).show();
                    }
                }catch (Exception e){
                }

            }

        });




        //Split Radio Group

        splitBy.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup radioGroup, int i) {
                try {


                    if (i == R.id.rbOne) {
                        String k = String.format("%.2f", m);
                        tp.setText(getString(R.string.dollor) +k );
                    } else if (i == R.id.rbTwo) {
                        String k = String.format("%.2f", m / 2);
                        tp.setText(getString(R.string.dollor)+k );
                    } else if (i == R.id.rbThree) {
                        String k = String.format("%.2f", m / 3);
                        tp.setText(getString(R.string.dollor)+k );
                    } else if (i == R.id.rbFour) {
                        String k = String.format("%.2f", m / 4);
                        tp.setText(getString(R.string.dollor) +k );
                    }
                }catch (Exception e){

                }
            }
        });

        clear.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                rbOne.setChecked(true);
                rbTen.setChecked(true);
                customPer.setProgress(40);
                edEnterBillAmount.setText(R.string.empty);
                tipValue.setText(getString(R.string.dollorZero));
                totalValue.setText(getString(R.string.dollorZero));
                tp.setText(getString(R.string.dollorZero));

            }
        });

    }
}






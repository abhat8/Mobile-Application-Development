package com.example.in_class_04;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;

import android.os.Bundle;
import android.util.Log;

public class MainActivity extends AppCompatActivity implements LoginFragment.LoginInterface, RegisterFragment.success, AccountFragment.AccountFragmentInterface, UpdateAccountFragment.UpdateAccountInterface {

    final String TAG = "demo";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //Initial View Login Frag

        getSupportFragmentManager().beginTransaction()
                .add(R.id.rootView,new LoginFragment(), "LoginFragment")
                .commit();


    }

    @Override
    public void sendAcc(DataServices.Account acc) {

        DataServices.Account a = acc;

        getSupportFragmentManager().beginTransaction()
                .replace(R.id.rootView, new AccountFragment().newInstance(a), "Account Frag")
                .commit();

    }


    @Override
    public void toReg() {
        getSupportFragmentManager().beginTransaction()
                .replace(R.id.rootView,new RegisterFragment(), "RegisterFragment")
                .commit();
    }

    @Override
    public void succAccDetails(DataServices.Account acc) {
        DataServices.Account a = acc;
        Log.d(TAG, "sendAcc: Creation Passed "+ a.getName()+ " "+a.getEmail()+" "+a.getPassword() );

        getSupportFragmentManager().beginTransaction()
                .addToBackStack(null)
                .replace(R.id.rootView, new AccountFragment().newInstance(a))
                .commit();
    }

    @Override
    public void RegCancel(boolean a) {
        if (a){
            getSupportFragmentManager().beginTransaction()
                    .replace(R.id.rootView, new LoginFragment())
                    .commit();

        }

    }

    @Override
    public void update(DataServices.Account acc) {
        DataServices.Account account = acc;

        getSupportFragmentManager().beginTransaction()
                .addToBackStack(null)
                .replace(R.id.rootView, UpdateAccountFragment.newInstance(acc))
                .commit();

    }

    @Override
    public void cancel(boolean a) {
        if (a){

            getSupportFragmentManager().beginTransaction()
                    .replace(R.id.rootView, new LoginFragment())
                    .commit();

        }
    }

    @Override
    public void updateAcc(DataServices.Account account) {

        getSupportFragmentManager().beginTransaction()
                .replace(R.id.rootView, new AccountFragment().newInstance(account))
                .commit();

    }

    @Override
    public void finish(boolean a) {
        if (a){
            getSupportFragmentManager().popBackStack();
        }
    }


}
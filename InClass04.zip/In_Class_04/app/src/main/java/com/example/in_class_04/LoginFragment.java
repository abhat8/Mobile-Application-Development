package com.example.in_class_04;

import android.content.Context;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class LoginFragment extends Fragment {

    private static final String ARG_PARAM1_EMAIL = "ARG_PARAM1_EMAIL";
    private static final String ARG_PARAM2_PASS = "ARG_PARAM2_PASS";


    private String email;
    private String pass;


    EditText editTextTextEmailAddress;
    EditText editTextTextPassword;
    Button buttonLogin;
    Button buttonCNA;

    public LoginFragment() {
        // Required empty public constructor
    }



    public static LoginFragment newInstance(String email, String pass) {
        LoginFragment fragment = new LoginFragment();
        Bundle args = new Bundle();
        args.putString(ARG_PARAM1_EMAIL, email);
        args.putString(ARG_PARAM2_PASS, pass);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        if (getArguments() != null) {
            this.email = getArguments().getString(ARG_PARAM1_EMAIL);
            this.pass = getArguments().getString(ARG_PARAM2_PASS);
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View v = inflater.inflate(R.layout.fragment_login, container, false);

        editTextTextEmailAddress = v.findViewById(R.id.etLoginEmail);
        editTextTextPassword = v.findViewById(R.id.etLoginPass);
        buttonLogin = v.findViewById(R.id.buttonLogin);
        getActivity().setTitle("Login");
        buttonLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                try{
                    String email1 = editTextTextEmailAddress.getText().toString();
                    String pass1 = editTextTextPassword.getText().toString();

                    if (email1.isEmpty() || pass1.isEmpty()){
                        Toast.makeText(getActivity(), getString(R.string.enterProp), Toast.LENGTH_SHORT).show();

                    }else {
                        DataServices.AccountRequestTask task = DataServices.login(email1,pass1);
                        if (task.isSuccessful()){

                            DataServices.Account acc = task.getAccount();
                            mLis.sendAcc(acc);
                        }else {
                            Toast.makeText(getActivity(), task.getErrorMessage(), Toast.LENGTH_SHORT).show();
                        }

                    }
                }catch (Exception e){
                    Log.d("demo", "onClick: "+e);
                }
            }

        });


        buttonCNA = v.findViewById(R.id.buttonCNA);
        buttonCNA.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                mLis.toReg();
            }
        });


        return v;


    }

    @Override
    public void onAttach(@NonNull Context context) {

        if (context instanceof LoginInterface){
            mLis = (LoginInterface) context;
        }else {
            throw new RuntimeException(getString(R.string.Implementmethod));
        }
        super.onAttach(context);
    }

    LoginInterface mLis;


    public interface LoginInterface{
        void sendAcc(DataServices.Account acc);
        void toReg();
    }
}
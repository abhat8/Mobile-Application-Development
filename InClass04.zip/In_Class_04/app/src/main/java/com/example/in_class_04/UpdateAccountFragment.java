package com.example.in_class_04;

import android.content.Context;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class UpdateAccountFragment extends Fragment {


    final String TAG = "demo";

    private static final String ARG_PARAM1 = "param1";

    private DataServices.Account acc;

    public UpdateAccountFragment() {
        // Required empty public constructor
    }

    public static UpdateAccountFragment newInstance(DataServices.Account account) {
        UpdateAccountFragment fragment = new UpdateAccountFragment();
        Bundle args = new Bundle();
        args.putSerializable(ARG_PARAM1, account);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            this.acc = (DataServices.Account) getArguments().getSerializable(ARG_PARAM1);
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View v =inflater.inflate(R.layout.fragment_update_account, container, false);


        TextView textView3 = v.findViewById(R.id.textView3);
        EditText editTextTextEmailAddress4 = v.findViewById(R.id.etUpAccName);
        EditText editTextTextPassword3 = v.findViewById(R.id.etUpAccPass);
        textView3.setText(acc.getEmail());

        getActivity().setTitle(getString(R.string.update));

        v.findViewById(R.id.buttonUpAccSub).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                String  name = editTextTextEmailAddress4.getText().toString();
                String pass = editTextTextPassword3.getText().toString();
                if (name.isEmpty() || pass.isEmpty()){
                    Toast.makeText(getActivity(), getString(R.string.enterProp), Toast.LENGTH_SHORT).show();
                    
                }else
                {
                    DataServices.AccountRequestTask task = DataServices.update(acc,name,pass);
                    mListner.updateAcc(task.getAccount());
                }
                
            }
        });

        v.findViewById(R.id.buttonUppAccCancel).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                mListner.finish(true);

            }
        });




        return v;
    }


    @Override
    public void onAttach(@NonNull Context context) {
        if (context instanceof UpdateAccountInterface){
            mListner = (UpdateAccountInterface) context;
        }
        super.onAttach(context);
    }

    UpdateAccountInterface mListner;



    interface UpdateAccountInterface{
        void updateAcc(DataServices.Account account);
        void finish(boolean a);
    }

}
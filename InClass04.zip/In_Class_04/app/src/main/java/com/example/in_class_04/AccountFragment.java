package com.example.in_class_04;

import android.content.Context;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;


public class AccountFragment extends Fragment {


    private static final String ARG_PARAM1 = "ARG_PARAM1";


    private DataServices.Account s1;

    public AccountFragment() {
        // Required empty public constructor
    }



    public AccountFragment newInstance(DataServices.Account a) {
        AccountFragment fragment = new AccountFragment();
        Bundle args = new Bundle();
        args.putSerializable(ARG_PARAM1, a);
        fragment.setArguments(args);
        this.s1 = a;

        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            this.s1 = (DataServices.Account) getArguments().getSerializable(ARG_PARAM1);

        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View v = inflater.inflate(R.layout.fragment_account, container, false);

        TextView textView2 = v.findViewById(R.id.textView2);
        textView2.setText(s1.getName());

        Button button5 = v.findViewById(R.id.buttonAccEditProf);
        Button button6 = v.findViewById(R.id.buttonAccLogOut);

        getActivity().setTitle(getString(R.string.account));



        button5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                mListner.update(s1);

            }
        });

        button6.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                mListner.cancel(true);
            }
        });

        return  v;
    }

    @Override
    public void onAttach(@NonNull Context context) {
        if (context instanceof AccountFragmentInterface){
            mListner = (AccountFragmentInterface) context;
        }
        super.onAttach(context);
    }

    AccountFragmentInterface mListner;

    interface AccountFragmentInterface{
        void update(DataServices.Account acc);
        void cancel(boolean a);
    }
}
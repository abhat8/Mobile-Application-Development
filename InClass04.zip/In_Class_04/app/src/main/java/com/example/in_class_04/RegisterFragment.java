package com.example.in_class_04;

import android.content.Context;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;


public class RegisterFragment extends Fragment {

    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";

    private String mParam1;
    private String mParam2;

    public RegisterFragment() {
        // Required empty public constructor
    }

    public static RegisterFragment newInstance(String param1, String param2) {
        RegisterFragment fragment = new RegisterFragment();
        Bundle args = new Bundle();
        args.putString(ARG_PARAM1, param1);
        args.putString(ARG_PARAM2, param2);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mParam1 = getArguments().getString(ARG_PARAM1);
            mParam2 = getArguments().getString(ARG_PARAM2);
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View v =inflater.inflate(R.layout.fragment_register, container, false);

        EditText editTextTextEmailAddress2= v.findViewById(R.id.etRegName);
        EditText editTextTextEmailAddress3 = v.findViewById(R.id.etRegEmail);
        EditText editTextTextPassword2 = v.findViewById(R.id.etRegPass);

        getActivity().setTitle(getString(R.string.RegisterAcc));


        Button button2 = v.findViewById(R.id.buttonRegSub);
        button2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String name = editTextTextEmailAddress2.getText().toString();
                String email = editTextTextEmailAddress3.getText().toString();
                String pass = editTextTextPassword2.getText().toString();

                if (name.isEmpty() || pass.isEmpty() || email.isEmpty()){
                    Toast.makeText(getActivity(),R.string.ns, Toast.LENGTH_SHORT).show();
                }else{
                    DataServices.AccountRequestTask task = DataServices.register(name,email,pass);
                    if (task.isSuccessful()){
                        DataServices.Account acc = task.getAccount();
                        mListner.succAccDetails(acc);
                    }
                    else{
                        Toast.makeText(getActivity(), task.getErrorMessage(), Toast.LENGTH_SHORT).show();
                    }
                }



            }
        });

        v.findViewById(R.id.buttonRegCancel).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                mListner.RegCancel(true);

            }
        });

        return v;
    }


    @Override
    public void onAttach(@NonNull Context context) {

        if (context instanceof success){
            mListner = (success) context;
        }else{
            throw new RuntimeException(getString(R.string.Implementmethod));
        }
        super.onAttach(context);
    }

    success mListner;


    interface success{
        void succAccDetails(DataServices.Account acc);
        void RegCancel(boolean a);
    }



}
package com.example.inclass05;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity implements AppCat.IappCat, AppListFragment.IAppListFragment {


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        getSupportFragmentManager().beginTransaction()
                .add(R.id.root,new AppCat())
                .commit();

    }


    @Override
    public void sendCat(String cat) {

        getSupportFragmentManager().beginTransaction()
                .replace(R.id.root, AppListFragment.newInstance(cat))
                .addToBackStack(null)
                .commit();
    }

    @Override
    public void sendAppName(DataServices.App app) {

        getSupportFragmentManager().beginTransaction()
                .replace(R.id.root,AppDetailsFragment.newInstance(app))
                .addToBackStack(null)
                .commit();
    }
}
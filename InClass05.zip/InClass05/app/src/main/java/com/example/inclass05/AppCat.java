package com.example.inclass05;

import android.content.Context;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import java.util.ArrayList;

public class AppCat extends Fragment {

    private static final String ARG_PARAM1 = "param1";

    private String mParam1;


    public AppCat() {
        // Required empty public constructor
    }


    public static AppCat newInstance(String param1) {
        AppCat fragment = new AppCat();
        Bundle args = new Bundle();
        args.putString(ARG_PARAM1, param1);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mParam1 = getArguments().getString(ARG_PARAM1);

        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {



        View v = inflater.inflate(R.layout.fragment_app_cat, container, false);

        getActivity().setTitle(getString(R.string.AppCategory));

        ArrayList<String> app = DataServices.getAppCategories();


            ListView listview;
            ArrayAdapter<String> adapter;

            listview = v.findViewById(R.id.listView);


            adapter = new ArrayAdapter<>(v.getContext(), android.R.layout.simple_list_item_1,android.R.id.text1, app);
            listview.setAdapter(adapter);

            listview.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                @Override
                public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                    mListner.sendCat(app.get(i));
                }
            });



        return v;
    }

    @Override
    public void onAttach(@NonNull Context context) {
        if (context instanceof IappCat){
            mListner = (IappCat)context;
        }
        super.onAttach(context);
    }

    IappCat mListner;

    interface IappCat{
        void sendCat(String cat);
    }

}
package com.example.inclass05;

import android.content.Context;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;

import java.util.ArrayList;


public class AppListFragment extends Fragment {

    ArrayList<DataServices.App> apps;

    private static final String ARG_PARAM1 = "param1";

    private String mParam1;


    public AppListFragment() {
        // Required empty public constructor
    }


    public static AppListFragment newInstance(String param1) {
        AppListFragment fragment = new AppListFragment();
        Bundle args = new Bundle();
        args.putString(ARG_PARAM1, param1);

        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            this.mParam1 = getArguments().getString(ARG_PARAM1);
            this.apps = DataServices.getAppsByCategory(mParam1);

        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View v = inflater.inflate(R.layout.fragment_app_list, container, false);

        getActivity().setTitle(mParam1);


        UserAdapter adapter;
        ListView lc;


        lc = v.findViewById(R.id.appListView);
        adapter = new UserAdapter(v.getContext(),R.layout.custom_layout,apps);
        lc.setAdapter(adapter);
        lc.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                mListner.sendAppName(apps.get(i));
            }
        });



        return v;
    }

    @Override
    public void onAttach(@NonNull Context context) {
        if (context instanceof IAppListFragment){
            mListner = (IAppListFragment) context;
        }
        super.onAttach(context);
    }

    IAppListFragment mListner;

    interface IAppListFragment{
        void sendAppName(DataServices.App app);
    }

}
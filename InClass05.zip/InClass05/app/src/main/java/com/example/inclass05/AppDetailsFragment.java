package com.example.inclass05;

import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;


public class AppDetailsFragment extends Fragment {

    private static final String ARG_PARAM1 = "param1";


    private DataServices.App mParam1;

    public AppDetailsFragment() {
        // Required empty public constructor
    }


    public static AppDetailsFragment newInstance(DataServices.App param1) {
        AppDetailsFragment fragment = new AppDetailsFragment();
        Bundle args = new Bundle();
        args.putSerializable(ARG_PARAM1, param1);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mParam1 = (DataServices.App) getArguments().getSerializable(ARG_PARAM1);
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        // Inflate the layout for this fragment
        View v = inflater.inflate(R.layout.fragment_app_details, container, false);

        getActivity().setTitle(getString(R.string.appdetails));

        TextView DAppName = v.findViewById(R.id.DAppName);
        TextView DArtName = v.findViewById(R.id.DArtName);
        TextView DReleaseDate = v.findViewById(R.id.DReleaseDate);

        DAppName.setText(mParam1.name);
        DArtName.setText(mParam1.artistName);
        DReleaseDate.setText(mParam1.releaseDate);

        ListView listView = v.findViewById(R.id.DlistView);
        ArrayAdapter<String> adapter;
        adapter = new ArrayAdapter<>(v.getContext(), android.R.layout.simple_list_item_1,android.R.id.text1,mParam1.genres);
        listView.setAdapter(adapter);


        return v;
    }
}
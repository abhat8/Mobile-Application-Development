package com.example.hw_05;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import com.google.firebase.auth.FirebaseAuth;

public class MainActivity extends AppCompatActivity implements LoginFragment.loginInt,CreateNewUserFragment.createUserInt,ForumsFragment.forumInt,NewForumFragment.NewForumInt {


    FirebaseAuth mAuth;
    ForumsFragment Forumfrag = new ForumsFragment();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        mAuth = FirebaseAuth.getInstance();

        if (mAuth.getCurrentUser() != null){
            getSupportFragmentManager().beginTransaction()
                    .replace(R.id.rootView, Forumfrag)
                    .commit();

        }else{
            getSupportFragmentManager().beginTransaction()
                    .replace(R.id.rootView, new LoginFragment())
                    .commit();
        }
      /*  getSupportFragmentManager().beginTransaction()
                .replace(R.id.rootView, new LoginFragment())
                .commit();*/

    }

    @Override
    public void cancel() {
        getSupportFragmentManager().beginTransaction()
                .replace(R.id.rootView, new LoginFragment())
                .commit();
    }

    @Override
    public void gotoForums() {
        getSupportFragmentManager().beginTransaction()
                .replace(R.id.rootView, Forumfrag)
                .commit();
    }

    @Override
    public void goToForums() {
        getSupportFragmentManager().beginTransaction()
                .replace(R.id.rootView, Forumfrag)
                .commit();
    }

    @Override
    public void goToCreateNewUser() {

        getSupportFragmentManager().beginTransaction()
                .replace(R.id.rootView, new CreateNewUserFragment())
                .addToBackStack(null)
                .commit();

    }

    @Override
    public void logout() {
        getSupportFragmentManager().beginTransaction()
                .replace(R.id.rootView, new LoginFragment())
                .addToBackStack(null)
                .commit();
    }

    @Override
    public void newForum() {
        getSupportFragmentManager().beginTransaction()
                .replace(R.id.rootView, new NewForumFragment())
                .addToBackStack(null)
                .commit();

    }

    @Override
    public void goToComments(post post_id) {
        getSupportFragmentManager().beginTransaction()
                .replace(R.id.rootView, CommentFragment.newInstance(post_id))
                .addToBackStack(null)
                .commit();
    }

    @Override
    public void Forumcancel() {
        getSupportFragmentManager().popBackStack();
    }

    @Override
    public void CreateSuccessfullGotoForums() {
        getSupportFragmentManager().beginTransaction()
                .replace(R.id.rootView, Forumfrag)
                .commit();
    }
}
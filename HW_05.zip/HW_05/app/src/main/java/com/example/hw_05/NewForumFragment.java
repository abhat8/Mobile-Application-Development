package com.example.hw_05;

import android.content.Context;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.FieldValue;
import com.google.firebase.firestore.FirebaseFirestore;

import java.text.ParseException;
import java.util.HashMap;

public class NewForumFragment extends Fragment {

    EditText newForumTitle,newForumDisc;
    String title,disc;
    FirebaseFirestore db;
    FirebaseAuth mAuth;
    final String TAG = "demo";

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_new_forum, container, false);

        newForumDisc = view.findViewById(R.id.newForumDisc);
        newForumTitle = view.findViewById(R.id.newForumTitle);
        db = FirebaseFirestore.getInstance();
        mAuth = FirebaseAuth.getInstance();

        return view;
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        view.findViewById(R.id.NewForumSubmit).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //New forum Code

                title = newForumTitle.getText().toString();
                disc = newForumDisc.getText().toString();
                if (title.isEmpty()){
                    Toast.makeText(getContext(), "Enter Title", Toast.LENGTH_SHORT).show();
                }else if(disc.isEmpty()){
                    Toast.makeText(getContext(), "Enter Description", Toast.LENGTH_SHORT).show();
                }else{
                    //attempt to create new post on firebase
                    
                    DocumentReference docRef = db.collection("forums1").document();
                    String path = docRef.getId();
                    HashMap<String, Object> likes = new HashMap<>();


                    db.collection("Forums1");

                    try {
                        HashMap<String, Object> toAdd = new HashMap<>();
                        toAdd.put("disc",disc);
                        toAdd.put("likes",likes);
                        toAdd.put("owner_id",mAuth.getCurrentUser().getUid());
                        toAdd.put("owner_name",mAuth.getCurrentUser().getDisplayName());
                        toAdd.put("post_id",path);
                        toAdd.put("title",title);
                        toAdd.put("timeStamp",FieldValue.serverTimestamp());

                        db.collection("Forums1").document(path)

                                //.set(new post(disc,mAuth.getCurrentUser().getUid(),mAuth.getCurrentUser().getDisplayName(),title,path,likes))
                                //set(new post(disc,mAuth.getCurrentUser().getUid(),mAuth.getCurrentUser().getDisplayName(),title,path,likes,FieldValue.serverTimestamp()))

                                .set(toAdd)
                                .addOnSuccessListener(getActivity(), new OnSuccessListener<Void>() {
                                    @Override
                                    public void onSuccess(Void unused) {
                                        Toast.makeText(getContext(), "Success", Toast.LENGTH_LONG).show();
                                        Log.d(TAG, "onSuccess: Added Successfully");
                                        mListner.CreateSuccessfullGotoForums();
                                    }

                                })
                                .addOnFailureListener(getActivity(), new OnFailureListener() {
                                    @Override
                                    public void onFailure(@NonNull Exception e) {
                                        Toast.makeText(getContext(), "Failed", Toast.LENGTH_LONG).show();
                                        Log.d(TAG, "onFailure: Failed "+e.getMessage());
                                    }
                                });
                    } catch (Exception e) {

                    }


                }

            }
        });

        view.findViewById(R.id.NewForumCancel).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //Cancel Code
                mListner.Forumcancel();
            }
        });
    }

    @Override
    public void onAttach(@NonNull Context context) {
        super.onAttach(context);
        mListner = (NewForumInt) context;
    }

    NewForumInt mListner;

    interface NewForumInt{
        void Forumcancel();
        void CreateSuccessfullGotoForums();
    }

}
package com.example.hw_05;

import android.annotation.SuppressLint;
import android.app.ProgressDialog;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.EventListener;
import com.google.firebase.firestore.FieldValue;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.FirebaseFirestoreException;
import com.google.firebase.firestore.Query;
import com.google.firebase.firestore.QuerySnapshot;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;


public class CommentFragment extends Fragment {

    final String TAG = "demo";
    private static final String ARG_PARAM1 = "param1";

    private post mParam1;
    RecyclerView recyclerView;
    LinearLayoutManager layoutManager;
    commentRecyclerViewAdapter adapter;
    ArrayList<Comment> comments;
    TextView postName,postOwnerName,postDisc,commentNoOf;
    Button button2;
    EditText editTextTextPersonName2;

    FirebaseAuth mAuth;
    FirebaseFirestore db;
    ProgressDialog processDialogue;


    public CommentFragment() {
        // Required empty public constructor
    }

    public static CommentFragment newInstance(post param1) {
        CommentFragment fragment = new CommentFragment();
        Bundle args = new Bundle();
        args.putSerializable(ARG_PARAM1, (Serializable) param1);
        fragment.setArguments(args);
        return fragment;
    }


    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mParam1 = (post) getArguments().getSerializable(ARG_PARAM1);
        }

    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_comment, container, false);

        postName = view.findViewById(R.id.postName);
        postName.setText(mParam1.title);
        postOwnerName = view.findViewById(R.id.postOwnerName);
        postOwnerName.setText(mParam1.owner_name);
        postDisc = view.findViewById(R.id.postDisc);
        postDisc.setText(mParam1.disc);
        commentNoOf = view.findViewById(R.id.commentNoOf);
        editTextTextPersonName2 = view.findViewById(R.id.editTextTextPersonName2);
        button2 = view.findViewById(R.id.button2);

        recyclerView = view.findViewById(R.id.commentRecylerView);
        recyclerView.setHasFixedSize(true);
        layoutManager = new LinearLayoutManager(getActivity());
        recyclerView.setLayoutManager(layoutManager);
        comments = new ArrayList<>();

        mAuth = FirebaseAuth.getInstance();
        db = FirebaseFirestore.getInstance();

        processDialogue = new ProgressDialog(getContext());
        processDialogue.setCancelable(false);
        processDialogue.setMessage("Fetching ..");
        processDialogue.show();


        return view;
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        Log.d(TAG, "onViewCreated: Recived post id "+mParam1);

        //getting Comments
        db.collection("Forums1")
                .document(mParam1.post_id)
                .collection("Comment")
                .get()
                .addOnSuccessListener(getActivity(), new OnSuccessListener<QuerySnapshot>() {
                    @Override
                    public void onSuccess(QuerySnapshot queryDocumentSnapshots) {
                        for (DocumentSnapshot doc:queryDocumentSnapshots.getDocuments()) {
                            comments.add(doc.toObject(Comment.class));
                            Log.d(TAG, "onSuccess: "+doc.getData());


                        }
                        adapter = new commentRecyclerViewAdapter(comments,mParam1);
                        commentNoOf.setText(String.valueOf(comments.size())+" Comments");
                        recyclerView.setAdapter(adapter);
                        if (processDialogue.isShowing()){
                            processDialogue.dismiss();
                        }

                        db.collection("Forums1")
                                .document(mParam1.post_id)
                                .collection("Comment").orderBy("timeStamp", Query.Direction.DESCENDING)
                                .addSnapshotListener(getActivity(), new EventListener<QuerySnapshot>() {
                                    @Override
                                    public void onEvent(@Nullable QuerySnapshot value, @Nullable FirebaseFirestoreException error) {
                                        comments.clear();
                                        for (DocumentSnapshot doc:value) {
                                            comments.add(doc.toObject(Comment.class));
                                            Log.d(TAG, "onSuccess: "+doc.getData());


                                        }
                                        adapter = new commentRecyclerViewAdapter(comments, mParam1);
                                        commentNoOf.setText(String.valueOf(comments.size())+" Comments");
                                        recyclerView.setAdapter(adapter);
                                        if (processDialogue.isShowing()){
                                            processDialogue.dismiss();
                                        }
                                    }
                                });

                    }
                });



        //Post button

        button2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String newComment = editTextTextPersonName2.getText().toString();
                if (newComment.isEmpty()){
                    Toast.makeText(getContext(), "Please Enter Something", Toast.LENGTH_SHORT).show();
                }else {
                    //Attemp To add comment to data base
                    //Comment toAdd = new Comment(newComment, mAuth.getCurrentUser().getUid(),mAuth.getCurrentUser().getDisplayName(), FieldValue.serverTimestamp());
                    HashMap<String, Object> toAdd = new HashMap<>();
                    DocumentReference docRef = db.collection("forums1").document(mParam1.post_id).collection("Comments").document();
                    String path = docRef.getId();
                    toAdd.put("comment_detail",newComment);
                    toAdd.put("owner_id",mAuth.getCurrentUser().getUid());
                    toAdd.put("owner_name",mAuth.getCurrentUser().getDisplayName());
                    toAdd.put("timeStamp",FieldValue.serverTimestamp());
                    toAdd.put("comment_id",path);
                    db.collection("Forums1")
                            .document(mParam1.post_id)
                            .collection("Comment")
                            .document(path)
                            .set(toAdd)
                            .addOnSuccessListener(getActivity(), new OnSuccessListener<Void>() {
                                @Override
                                public void onSuccess(Void unused) {
                                    Log.d(TAG, "onSuccess: New Comment Added");
                                    editTextTextPersonName2.setText("");
                                }
                            });
                }
            }
        });

    }

    //creating RecyclerViewAdapter

    static public class commentRecyclerViewAdapter extends RecyclerView.Adapter<userViewHolder>{


        ArrayList<Comment> data = new ArrayList<>();
        FirebaseAuth mAuth;
        FirebaseFirestore db;
        post temp;
        final String TAG = "demo";

        public commentRecyclerViewAdapter(ArrayList<Comment> data, post mParam1){
            this.data = data;
            this.temp = mParam1;
        }



        @NonNull
        @Override
        public userViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {

            View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.comment_layout,parent,false);
            mAuth = FirebaseAuth.getInstance();
            db = FirebaseFirestore.getInstance();

            userViewHolder viewHolder =  new userViewHolder(view);

            return viewHolder;
        }

        @Override
        public void onBindViewHolder(@NonNull userViewHolder holder, @SuppressLint("RecyclerView") int position) {

            holder.textView.setText(data.get(position).owner_name);
            holder.textView2.setText(data.get(position).comment_detail);
            holder.textView3.setText(data.get(position).getDateString());

            if (mAuth.getCurrentUser().getUid().equals(data.get(position).owner_id)){
                holder.imageView.setVisibility(View.VISIBLE);
                holder.imageView.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        db.collection("Forums1")
                                .document(temp.post_id)
                                .collection("Comment")
                                .document(data.get(position).comment_id)
                                .delete()
                                .addOnSuccessListener(new OnSuccessListener<Void>() {
                                    @Override
                                    public void onSuccess(Void unused) {
                                        Log.d(TAG, "onSuccess: Delete Successfull");

                                    }
                                });
                    }
                });
            }



        }

        @Override
        public int getItemCount() {
            return data.size();
        }
    }

    static  public class userViewHolder extends RecyclerView.ViewHolder{

        TextView textView,textView2,textView3;
        ImageView imageView;

        public userViewHolder(@NonNull View itemView) {
            super(itemView);
            textView = itemView.findViewById(R.id.textView);
            textView2 = itemView.findViewById(R.id.textView2);
            textView3 = itemView.findViewById(R.id.textView3);
            imageView = itemView.findViewById(R.id.imageView);
        }
    }

}

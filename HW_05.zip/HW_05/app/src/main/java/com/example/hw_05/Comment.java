package com.example.hw_05;

import com.google.firebase.Timestamp;
import com.google.firebase.firestore.Exclude;
import com.google.firebase.firestore.FieldValue;
import com.google.firebase.firestore.ServerTimestamp;

import java.text.SimpleDateFormat;

public class Comment {
   public String comment_detail,owner_id,owner_name,comment_id;
   public Timestamp timeStamp;

    public Comment(String newComment, String uid, String displayName,Timestamp timeStamp,String comment_id) {
        this.comment_detail = newComment;
        this.owner_id = uid;
        this.owner_name = displayName;
        this.timeStamp = timeStamp;
        this.comment_id = comment_id;
    }

    @Exclude
    public String getDateString(){
        SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyy hh:mm a");
        if (timeStamp== null){
            return "";
        }else {
            return sdf.format(timeStamp.toDate());
        }
    }

    public void setTimeStamp(Timestamp timeStamp) {
        this.timeStamp = timeStamp;
    }

    @ServerTimestamp  public Timestamp getTimeStamp() {
        return timeStamp;
    }

    public Comment() {
    }

    public String getComment_detail() {
        return comment_detail;
    }

    public void setComment_detail(String comment_detail) {
        this.comment_detail = comment_detail;
    }

    public String getOwner_id() {
        return owner_id;
    }

    public void setOwner_id(String owner_id) {
        this.owner_id = owner_id;
    }

    public String getOwner_name() {
        return owner_name;
    }

    public void setOwner_name(String owner_name) {
        this.owner_name = owner_name;
    }

    @Override
    public String toString() {
        return "Comment{" +
                "comment_detail='" + comment_detail + '\'' +
                ", owner_id='" + owner_id + '\'' +
                ", owner_name='" + owner_name + '\'' +
                '}';
    }
}

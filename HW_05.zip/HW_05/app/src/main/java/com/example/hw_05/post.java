package com.example.hw_05;

import com.google.firebase.Timestamp;
import com.google.firebase.firestore.Exclude;
import com.google.firebase.firestore.FieldValue;

import java.io.Serializable;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.HashMap;


public class post  implements Serializable {
    public String disc, owner_id,owner_name,title,post_id;
    public HashMap<String, Object> likes;
    //public FieldValue timeStamp;
    public Timestamp timeStamp;

    public Timestamp getTimeStamp() {
        return timeStamp;
    }

    public void setTimeStamp(Timestamp timeStamp) {
        this.timeStamp = timeStamp;
    }
    //public FieldValue timeStamp1;

        /*@Exclude public String getDateString(String t1){
            SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyy hh:mm a");
            if (timeStamp.equals("")){
                return "";
            }else {
                return sdf.format(timeStamp.toDate());
            }
        }*/


    public post(){}
    @Exclude public String getDateString(){
        SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyy hh:mm a");
        if (timeStamp== null){
            return "";
        }else {
            return sdf.format(timeStamp.toDate());
        }
    }



    public post(String disc, String owner_id, String owner_name, String title, String post_id,HashMap<String, Object> likes ) {
        this.disc = disc;
        this.owner_id = owner_id;
        this.owner_name = owner_name;
        this.title = title;
        this.likes = likes;
        this.post_id = post_id;
    }
    public post(String disc, String owner_id, String owner_name, String title, String post_id,HashMap<String, Object> likes, String timeStamp ) throws ParseException {
        this.disc = disc;
        this.owner_id = owner_id;
        this.owner_name = owner_name;
        this.title = title;
        this.likes = likes;
        this.post_id = post_id;
        //this.timeStamp = getDateString();

        /*String dtStart = timeStamp.toString();
        SimpleDateFormat fmt = new SimpleDateFormat("yyyy-MM-dd");
        Date date = fmt.parse(dtStart);
        date.toString();
        this.timeStamp.put("timeStamp",date.toString());*/
    }
    public post(String disc, String owner_id, String owner_name, String title, String post_id, HashMap<String, Object> likes, Timestamp timeStamp ) throws ParseException {
        this.disc = disc;
        this.owner_id = owner_id;
        this.owner_name = owner_name;
        this.title = title;
        this.likes = likes;
        this.post_id = post_id;
        this.timeStamp = timeStamp;
        /*String dtStart = timeStamp.toString();
        SimpleDateFormat fmt = new SimpleDateFormat("yyyy-MM-dd");
        Date date = fmt.parse(dtStart);
        date.toString();
        this.timeStamp.put("timeStamp",date.toString());*/
    }

    public post(String disc, String owner_id, String owner_name, String title, String post_id ) {
        this.disc = disc;
        this.owner_id = owner_id;
        this.owner_name = owner_name;
        this.title = title;
        this.post_id = post_id;
    }



    public String getDisc() {
        return disc;
    }

    public void setDisc(String disc) {
        this.disc = disc;
    }

    public String getOwner_id() {
        return owner_id;
    }

    public void setOwner_id(String owner_id) {
        this.owner_id = owner_id;
    }

    public String getOwner_name() {
        return owner_name;
    }

    public void setOwner_name(String owner_name) {
        this.owner_name = owner_name;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public HashMap<String, Object> getLikes() {
        return likes;
    }

    public void setLikes(HashMap<String, Object> likes) {
        this.likes = likes;
    }



    @Override
    public String toString() {
        return "post{" +
                "disc='" + disc + '\'' +
                ", owner_id='" + owner_id + '\'' +
                ", owner_name='" + owner_name + '\'' +
                ", title='" + title + '\'' +
                ", post_id='" + post_id + '\'' +
                ", likes=" + likes +
                '}';
    }

    public String getPost_id() {
        return post_id;
    }

    public void setPost_id(String post_id) {
        this.post_id = post_id;
    }

}


package com.example.hw_05;

import android.content.Context;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.auth.UserProfileChangeRequest;

public class CreateNewUserFragment extends Fragment {

    EditText getName,getEmail,getPassword;
    String name,email,password;
    FirebaseAuth mAuth;



    public CreateNewUserFragment() {
        // Required empty public constructor
    }



    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        mAuth = FirebaseAuth.getInstance();
        View view = inflater.inflate(R.layout.fragment_create_new_user, container, false);

        getEmail = view.findViewById(R.id.createEmail);
        getName = view.findViewById(R.id.createName);
        getPassword = view.findViewById(R.id.createPassword);
        return view;
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        view.findViewById(R.id.createSubmit).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //Create Code
                name = getName.getText().toString();
                email = getEmail.getText().toString();
                password = getPassword.getText().toString();
                if (name.isEmpty()){
                    Toast.makeText(getContext(), "Enter Name", Toast.LENGTH_SHORT).show();
                }else if(email.isEmpty()){
                    Toast.makeText(getContext(), "Enter Email", Toast.LENGTH_SHORT).show();

                }else if(password.isEmpty()){
                    Toast.makeText(getContext(), "Enter Password", Toast.LENGTH_SHORT).show();

                }else{
                    //Create New User
                    mAuth.createUserWithEmailAndPassword(email,password).addOnSuccessListener(getActivity(), new OnSuccessListener<AuthResult>() {
                        @Override
                        public void onSuccess(AuthResult authResult) {
                            FirebaseUser user = FirebaseAuth.getInstance().getCurrentUser();

                            UserProfileChangeRequest profileUpdates = new UserProfileChangeRequest.Builder()
                                    .setDisplayName(name)
                                    .build();

                            user.updateProfile(profileUpdates).addOnSuccessListener(getActivity(), new OnSuccessListener<Void>() {
                                @Override
                                public void onSuccess(Void unused) {
                                    Toast.makeText(getContext(), "Welcome "+name, Toast.LENGTH_SHORT).show();
                                    //Goto Forums Code
                                    mListner.gotoForums();
                                }
                            });

                        }
                    })
                            .addOnFailureListener(getActivity(), new OnFailureListener() {
                                @Override
                                public void onFailure(@NonNull Exception e) {
                                    Toast.makeText(getContext(), "Registration Failed "+e.getMessage(), Toast.LENGTH_LONG).show();
                                    getName.setText("");
                                    getEmail.setText("");
                                    getPassword.setText("");
                                }
                            });

                }
            }
        });

        view.findViewById(R.id.createCancel).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //Cancel Code
                mListner.cancel();
            }
        });


    }

    @Override
    public void onAttach(@NonNull Context context) {
        super.onAttach(context);
        mListner = (createUserInt) context;
    }

    createUserInt mListner;

    interface createUserInt{
        void cancel();
        void gotoForums();
    }

}
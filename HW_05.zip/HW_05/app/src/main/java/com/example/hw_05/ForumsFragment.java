package com.example.hw_05;

import android.annotation.SuppressLint;
import android.app.ProgressDialog;
import android.content.Context;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.EventListener;
import com.google.firebase.firestore.FieldValue;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.FirebaseFirestoreException;
import com.google.firebase.firestore.Query;
import com.google.firebase.firestore.QuerySnapshot;

import java.util.ArrayList;
import java.util.HashMap;


public class ForumsFragment extends Fragment {

    FirebaseAuth mAuth;
    RecyclerView recyclerView;
    LinearLayoutManager layoutManager;
    ArrayList<post> posts;
    forumRecyclerViewAdapter adapter;
    FirebaseFirestore db;
    final String TAG ="demo";
    ProgressDialog processDialogue;

    public ForumsFragment() {
        // Required empty public constructor
    }


    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_forums, container, false);
        mAuth = FirebaseAuth.getInstance();
        db = FirebaseFirestore.getInstance();
        recyclerView = view.findViewById(R.id.recyclerView);
        recyclerView.setHasFixedSize(true);
        layoutManager = new LinearLayoutManager(getActivity());
        recyclerView.setLayoutManager(layoutManager);
        posts = new ArrayList<>();

        processDialogue = new ProgressDialog(getContext());
        processDialogue.setCancelable(false);
        processDialogue.setMessage("Fetching ..");
        processDialogue.show();

        return view;
    }


    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);



        //Getting Forums for Firebase
        db.collection("Forums1").orderBy("timeStamp", Query.Direction.DESCENDING)
                .get()
                .addOnSuccessListener(getActivity(), new OnSuccessListener<QuerySnapshot>() {
                    @Override
                    public void onSuccess(QuerySnapshot queryDocumentSnapshots) {
                        for (DocumentSnapshot doc:queryDocumentSnapshots.getDocuments()) {
                            posts.add(doc.toObject(post.class));
                            Log.d(TAG, "onSuccess: "+doc.getData());


                        }
                        adapter = new forumRecyclerViewAdapter(posts,mListner);
                        recyclerView.setAdapter(adapter);
                        if (processDialogue.isShowing()){
                            processDialogue.dismiss();
                        }

                        FieldValue t1;
                        db.collection("Forums1").orderBy("timeStamp", Query.Direction.DESCENDING)
                                .addSnapshotListener(getActivity(), new EventListener<QuerySnapshot>() {
                            @Override
                            public void onEvent(@Nullable QuerySnapshot value, @Nullable FirebaseFirestoreException error) {
                                posts.clear();
                                for (DocumentSnapshot doc:value) {
                                    //toAdd.put("timeStamp",doc.get("timeStamp"));

                                    posts.add(doc.toObject(post.class));

                                    Log.d(TAG, "onSuccess: "+doc.getData());
                                    Log.d(TAG, "onSuccess: This is post"+posts.get(0));
                                }
                                adapter.notifyDataSetChanged();

                            }
                        });

                    }
                });



        view.findViewById(R.id.forumLogout).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //Logout Code
                mAuth.signOut();
                mListner.logout();
            }
        });

        view.findViewById(R.id.forumNew).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //New Forum Code
                mListner.newForum();
            }
        });

    }


    static class forumRecyclerViewAdapter extends RecyclerView.Adapter<forumUserAdapter>{

        ArrayList<post> data;
        FirebaseAuth mAuth;
        FirebaseFirestore db;
        final String TAG = "demo";
        forumInt mListner;


        public forumRecyclerViewAdapter(ArrayList<post> posts,forumInt mListner){
            this.data = posts;
            this.mListner = mListner;
        }

        @NonNull
        @Override
        public forumUserAdapter onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {

            View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.forum_post,parent,false);

            forumUserAdapter userViewHolder = new forumUserAdapter(view);



            return userViewHolder;
        }

        @Override
        public void onBindViewHolder(@NonNull forumUserAdapter holder, @SuppressLint("RecyclerView") int position) {


            mAuth = FirebaseAuth.getInstance();
            db = FirebaseFirestore.getInstance();
            post currentPost = data.get(position);
            holder.Posttitle.setText(currentPost.getTitle());
            holder.loc = position;
            holder.clickedPost = data.get(holder.loc);
            holder.PostOwner.setText(currentPost.getOwner_name());
            holder.PostTime.setText(currentPost.getDateString());
            holder.PostDisc.setText(currentPost.getDisc());
            try{
                String like_size = String.valueOf(currentPost.getLikes().size());
                holder.PostLikes.setText(like_size+ " Likes | ");
            }catch (Exception e){
                holder.PostLikes.setVisibility(View.INVISIBLE);
            };

            holder.button.setVisibility(View.VISIBLE);
            //which like button to display
            if (currentPost.likes.containsValue(mAuth.getCurrentUser().getUid())){
                holder.button.setImageResource(R.drawable.like_favorite);
            }else {
                holder.button.setImageResource(R.drawable.like_not_favorite);
            }

            //setting up listner

            holder.itemView1.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Log.d(TAG, "onClick: clicked on itemView"+ data.get(position));
                    post togo = data.get(position);
                    mListner.goToComments(togo);
                }
            });

            //delete code
            if (mAuth.getCurrentUser().getUid().equals(currentPost.owner_id)){
                //Owner of post Try to delete
                holder.imageButton.setVisibility(View.VISIBLE);
            }else{
                holder.imageButton.setVisibility(View.INVISIBLE);

            }


            //like Button
            holder.button.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                   if (currentPost.likes.containsValue(mAuth.getCurrentUser().getUid())){
                       un_likePost(currentPost);
                   }else {

                       like_post(currentPost);
                   }

                }
            });

            //delete button
            holder.imageButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    db.collection("Forums1").document(currentPost.post_id)
                            .delete()
                            .addOnSuccessListener(new OnSuccessListener<Void>() {
                                @Override
                                public void onSuccess(Void unused) {
                                    Log.d(TAG, "onSuccess: Post deleted Successfully");

                                }
                            })
                            .addOnFailureListener(new OnFailureListener() {
                                @Override
                                public void onFailure(@NonNull Exception e) {
                                    Log.d(TAG, "onSuccess: Post deleted Successfully");
                                }
                            });

                }
            });


        }

        @Override
        public int getItemCount() {
            return data.size();
        }


        void un_likePost(post currentPost){
            HashMap<String, Object > like = new HashMap<>();
            like = currentPost.likes;
            like.remove(mAuth.getCurrentUser().getDisplayName());
            db.collection("Forums1").document(currentPost.post_id)
                    .update("likes",like)
                    .addOnSuccessListener(new OnSuccessListener<Void>() {
                        @Override
                        public void onSuccess(Void unused) {
                            Log.d(TAG, "onSuccess: ");
                        }
                    })
            ;

        }

        void like_post(post currentPost){
            HashMap<String, Object > like = new HashMap<>();
            like = currentPost.likes;
            if (mAuth!= null){
                if (mAuth.getCurrentUser() != null){
                    if (mAuth.getCurrentUser().getDisplayName() != null){
                        if (mAuth.getCurrentUser().getUid() != null){
                            like.put(mAuth.getCurrentUser().getDisplayName(),mAuth.getCurrentUser().getUid());
                        }
                    }
                }
            }
            //like.put(mAuth.getCurrentUser().getDisplayName(),mAuth.getCurrentUser().getUid());
            db.collection("Forums1").document(currentPost.post_id)
            .update("likes",like)
            .addOnSuccessListener(new OnSuccessListener<Void>() {
                @Override
                public void onSuccess(Void unused) {
                    Log.d(TAG, "onSuccess: ");
                }
            })
            ;
                    
        }
    }

    static class forumUserAdapter extends RecyclerView.ViewHolder{

        final String TAG = "demo";
        TextView Posttitle,PostOwner,PostDisc,PostLikes,PostTime;
        ImageButton imageButton;
        ImageView button;
        int loc;
        View itemView1;
        post clickedPost;



        public forumUserAdapter(@NonNull View itemView) {
            super(itemView);
            Posttitle = itemView.findViewById(R.id.Posttitle);
            PostOwner = itemView.findViewById(R.id.PostOwner);
            PostDisc = itemView.findViewById(R.id.PostDisc);
            PostLikes = itemView.findViewById(R.id.PostLikes);
            PostTime = itemView.findViewById(R.id.PostTime);
            imageButton = itemView.findViewById(R.id.imageButton);
            button = itemView.findViewById(R.id.button);
            this.itemView1 = itemView;




        }
    }




    @Override
    public void onAttach(@NonNull Context context) {
        super.onAttach(context);
        if (context instanceof forumInt){
            mListner = (forumInt) context;
        }

    }

    public forumInt mListner;

    interface forumInt{
        void logout();
        void newForum();
        void goToComments(post post_id);

    }



}
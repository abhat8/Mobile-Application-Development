package edu.uncc.HW_04;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.DividerItemDecoration;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ListView;
import android.widget.TextView;

import com.google.gson.Gson;

import java.io.IOException;
import java.util.ArrayList;

import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.FormBody;
import okhttp3.HttpUrl;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;

public class PostsListFragment extends Fragment {
    private static final String ARG_USER_TOKEN = "ARG_USER_TOKEN";
    UserToken mUserToken;
    Button buttonCreate;
    Button buttonLogout;
    TextView textViewName;
    OkHttpClient client = new OkHttpClient();
    final String TAG = "TAG";
    PostsList postsList = new PostsList();
    PostsListAdapter postsListAdapter;
    RecyclerView postsListRecyclerView;
    RecyclerView pagerRecyclerView;
    RecyclerView.Adapter pageAdapter;
    TextView textViewPageStatus;
    Button deleteButton;


    public PostsListFragment() {
        // Required empty public constructor
    }

    public static PostsListFragment newInstance(UserToken userToken) {
        PostsListFragment fragment = new PostsListFragment();
        Bundle args = new Bundle();
        args.putSerializable(ARG_USER_TOKEN, userToken);
        fragment.setArguments(args);
        return fragment;
    }


    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mUserToken = (UserToken)getArguments().getSerializable(ARG_USER_TOKEN);
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View v= inflater.inflate(R.layout.fragment_posts_list, container, false);



        return v;
    }



    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        getActivity().setTitle("Posts");

        buttonCreate= view.findViewById(R.id.buttonCreatePost);
        buttonLogout = view.findViewById(R.id.buttonLogout);
        deleteButton = view.findViewById(R.id.deleteButton);
        textViewName = view.findViewById(R.id.textViewName);
        textViewPageStatus = view.findViewById(R.id.textViewPageStatus);
        textViewName.setText("Welcome "+mUserToken.fullname);
        postsListRecyclerView = view.findViewById(R.id.postsListRecyclerView);
        pagerRecyclerView = view.findViewById(R.id.pagerRecyclerView);
        
        
        //getting Post
        getPosts(1);
        postsList.posts = new ArrayList<>();
        postsListAdapter = new PostsListAdapter(postsList.posts);
        postsListRecyclerView.addItemDecoration(new DividerItemDecoration(getContext(), DividerItemDecoration.VERTICAL));
        postsListRecyclerView.setLayoutManager(new LinearLayoutManager(getContext()));
        postsListRecyclerView.setAdapter(postsListAdapter);


        buttonLogout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                SharedPreferences sharedPreferences = requireActivity().getSharedPreferences("data", Context.MODE_PRIVATE);
                SharedPreferences.Editor editor = sharedPreferences.edit();
                editor.remove("gson");
                editor.apply();
                mListner.goToLogin();


            }
        });
        buttonCreate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                mListner.goToCreate(mUserToken);
            }
        });

    }

    @Override
    public void onAttach(@NonNull Context context) {
        super.onAttach(context);
        if (context instanceof PostListFragInt){
            mListner = (PostListFragInt) context;
        }
    }

    PostListFragInt mListner ;


    interface PostListFragInt{
        void goToLogin();
        void goToCreate(UserToken user);
    }


    void setupPageRecyclerView(){
        int totalPages = (int) Math.ceil(postsList.totalCount/(float)postsList.pageSize);
        textViewPageStatus.setText("Showing " + postsList.page + " out of " + totalPages);
        LinearLayoutManager layoutManager = new LinearLayoutManager(requireContext(), LinearLayoutManager.HORIZONTAL, false);
        pageAdapter = new PageListAdapter(totalPages);
        pagerRecyclerView.setLayoutManager(layoutManager);
        pagerRecyclerView.setAdapter(pageAdapter);


    }



    void getPosts(int pageNumber){
        String token = mUserToken.token;

        HttpUrl url = new HttpUrl.Builder()
                .scheme("https")
                .host("www.theappsdr.com")
                .addPathSegment("posts")
                .addQueryParameter("page", String.valueOf(pageNumber))
                .build();

        Request request = new Request.Builder().url(url)
                .addHeader("Authorization", "BEARER "  + token)
                .build();

        client.newCall(request).enqueue(new Callback() {
            @Override
            public void onFailure(@NonNull Call call, @NonNull IOException e) {
                Log.d(TAG, "onFailure: FAILED TO GET POSTS");
            }

            @Override
            public void onResponse(@NonNull Call call, @NonNull Response response) throws IOException {
                if (response.isSuccessful()){

                    //trial code
                    Gson gson = new Gson();
                    PostsList list = gson.fromJson(response.body().string(), PostsList.class);
                    postsList.posts.clear();
                    postsList.page = list.page;
                    postsList.totalCount = list.totalCount;
                    postsList.pageSize = list.pageSize;
                    postsList.posts.addAll(list.posts);
                    getActivity().runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            postsListAdapter.notifyDataSetChanged();
                            setupPageRecyclerView();
                        }
                    });

                }
            }
        });
        
        
    }

    void deletePost(Post post) {
        HttpUrl url = new HttpUrl.Builder()
                .scheme("https")
                .host("www.theappsdr.com")
                .addPathSegment("posts")
                .addPathSegment("delete")
                .build();

        Request request = new Request.Builder().url(url)
                .addHeader("Authorization", "BEARER "  + mUserToken.token)
                .post(new FormBody.Builder().add("post_id", String.valueOf(post.postID)).build())
                .build();

        client.newCall(request).enqueue(new Callback() {
            @Override
            public void onFailure(@NonNull Call call, @NonNull IOException e) {
                Log.d("Delete", "onFailure: " + e.getMessage());
            }

            @Override
            public void onResponse(@NonNull Call call, @NonNull Response response) throws IOException {
                if(response.isSuccessful()) {
                    postsList.posts.remove(post);
                    getActivity().runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            postsListAdapter.notifyDataSetChanged();
                        }
                    });
                } else {
                    Log.d("Response", "onResponse: " + response.message());
                }
            }
        });
    }

    class PostsListAdapter extends RecyclerView.Adapter<PostsListAdapter.PostViewHolder>{

        private ArrayList<Post> posts;
        public PostsListAdapter(ArrayList<Post> posts) {
            this.posts = posts;
        }

        @NonNull
        @Override
        public PostViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            View view = LayoutInflater.from(getContext())
                    .inflate(R.layout.post_row, parent, false);
            PostViewHolder viewHolder = new PostViewHolder(view);
            return viewHolder;
        }

        @Override
        public void onBindViewHolder(@NonNull PostViewHolder holder, int position) {

            Post post = posts.get(position);
            holder.setupData(post);

        }

        @Override
        public int getItemCount() {
            return posts.size();
        }

        class PostViewHolder extends RecyclerView.ViewHolder{
            TextView textViewPost, textViewCreatedName, textViewCreatedTime;
            ImageButton deleteButton;

            public PostViewHolder(@NonNull View itemView) {
                super(itemView);
                textViewPost = itemView.findViewById(R.id.textViewPost);
                textViewCreatedName = itemView.findViewById(R.id.textViewCreatedName);
                textViewCreatedTime = itemView.findViewById(R.id.textViewCreatedTime);
                deleteButton = itemView.findViewById(R.id.deleteButton);
            }

            public void setupData(Post post) {
                textViewPost.setText(post.text);
                textViewCreatedName.setText(post.createdByName);
                textViewCreatedTime.setText(post.createdAt);

                if (post.createByUID.contentEquals(mUserToken.userId)) {
                    deleteButton.setVisibility(View.VISIBLE);
                    deleteButton.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View view) {
                            deletePost(post);
                        }
                    });
                } else {
                    deleteButton.setVisibility(View.INVISIBLE);
                }
            }


        }




    }

    class PageListAdapter extends RecyclerView.Adapter<PageListAdapter.PageNumberViewHolder>{

        private int pageCount;
        public PageListAdapter(int count) {
            this.pageCount = count;
        }

        @NonNull
        @Override
        public PageNumberViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            View view = LayoutInflater.from(getContext())
                    .inflate(R.layout.page_number_row, parent, false);
            PageNumberViewHolder viewHolder = new PageNumberViewHolder(view);
            return viewHolder;
        }

        @Override
        public void onBindViewHolder(@NonNull PageNumberViewHolder holder, int position) {
            holder.setupData(position + 1);
        }

        @Override
        public int getItemCount() {
            return pageCount;
        }

        class PageNumberViewHolder extends RecyclerView.ViewHolder{

            TextView textViewPageNumber;

            public PageNumberViewHolder(@NonNull View itemView) {
                super(itemView);
                textViewPageNumber = itemView.findViewById(R.id.textViewPageNumber);
            }


            public void setupData(int i) {
                textViewPageNumber.setText(String.valueOf(i));
                textViewPageNumber.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        getPosts(i);
                    }
                });
            }

        }



    }


}
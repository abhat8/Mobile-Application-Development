package edu.uncc.HW_04;

import com.google.gson.annotations.SerializedName;

public class Post {
    @SerializedName(value = "post_id")
    String postID;
    @SerializedName(value = "created_by_uid")
    String createByUID;
    @SerializedName(value = "post_text")
    String text;
    @SerializedName(value = "created_at")
    String createdAt;
    @SerializedName(value = "created_by_name")
    String createdByName;
}

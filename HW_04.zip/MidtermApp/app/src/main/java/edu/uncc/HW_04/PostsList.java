package edu.uncc.HW_04;

import java.util.ArrayList;

public class PostsList {
    ArrayList<Post> posts;
    float totalCount;
    int page;
    int pageSize;
}

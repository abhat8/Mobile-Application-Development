package com.example.inclass3;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    static final String TAG = "demo";
    final public static  int REQ_CODE = 100;
    static final String User = "User";

    EditText editTextEnterEmail;
    EditText editTextEnterName;
    EditText editTextEnterId;
    Button buttonSelect;
    Button buttonSubmit;
    TextView textViewDeptMain;
    String name;
    String email;
    String id;
    String dept;
    int flag = 0;


    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode == RESULT_OK){
            String name = data.getStringExtra(Department.KEY);
            dept = name;
            textViewDeptMain.setText(dept);

        }else if(resultCode == RESULT_CANCELED){
            Toast.makeText(MainActivity.this, R.string.canceled, Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);




        //intialize var
        editTextEnterEmail = findViewById(R.id.editTextEnterEmail);
        editTextEnterName = findViewById(R.id.editTextEnterName);
        editTextEnterId = findViewById(R.id.editTextEnterId);
        buttonSelect = findViewById(R.id.buttonSelect);
        buttonSubmit = findViewById(R.id.buttonSubmit);
        textViewDeptMain = findViewById(R.id.textViewDeptMain);


        setTitle(R.string.title1);
        //OnSelectButton



        buttonSelect.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Intent intent = new Intent(MainActivity.this, Department.class);
                flag = 1;
                startActivityForResult(intent, REQ_CODE);

            }

        });

        buttonSubmit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                name = editTextEnterName.getText().toString();
                email = editTextEnterEmail.getText().toString();
                id = editTextEnterId.getText().toString();

                Intent intent = new Intent(MainActivity.this,Profile.class);
                intent.putExtra(User,new Profile(name,email,id,dept));

                if (name.isEmpty()){

                    Toast.makeText(MainActivity.this, R.string.msg1, Toast.LENGTH_SHORT).show();
                }else if (email.isEmpty()){

                    Toast.makeText(MainActivity.this, R.string.msg2, Toast.LENGTH_SHORT).show();
                }else if (id.isEmpty()){

                    Toast.makeText(MainActivity.this, R.string.msg3, Toast.LENGTH_SHORT).show();
                }else{
                    startActivity(intent);
                }


            }
        });










    }
}
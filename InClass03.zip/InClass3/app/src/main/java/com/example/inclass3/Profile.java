package com.example.inclass3;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;
import android.widget.TextView;
import android.widget.Toast;

import java.io.Serializable;

public class Profile extends AppCompatActivity implements Serializable {
    String name,email,id,dept;

    public Profile(String name, String email, String id, String dept) {
        this.name = name;
        this.email = email;
        this.id = id;
        this.dept = dept;
    }

    public Profile() {
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profile);
        setTitle(R.string.Profile);

        Profile p = (Profile) getIntent().getSerializableExtra(MainActivity.User);

        TextView textViewname = findViewById(R.id.textViewname);
        textViewname.setText(p.name);

        TextView textViewemail = findViewById(R.id.textViewemail);
        textViewemail.setText(p.email);

        TextView textViewid = findViewById(R.id.textViewid);
        textViewid.setText(p.id);

        TextView textViewdept = findViewById(R.id.textViewdept);
        textViewdept.setText(p.dept);








    }
}
package com.example.inclass3;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;

public class Department extends AppCompatActivity {

    final static public String KEY = "key";

    RadioGroup radioGroupCourse;
    RadioButton radioButtonComputer;
    RadioButton radioButtonSoftware;
    RadioButton radioButtonBio;
    RadioButton radioButtonData;
    Button buttonSelectDept;
    Button buttonCancel;
    int i;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_department);
        setTitle(R.string.department);

        //Intialize var

        radioGroupCourse = findViewById(R.id.radioGroupCourse);
        radioButtonComputer = findViewById(R.id.radioButtonComputer);
        radioButtonSoftware = findViewById(R.id.radioButtonSoftware);
        radioButtonBio = findViewById(R.id.radioButtonBio);
        radioButtonData = findViewById(R.id.radioButtonData);
        buttonSelectDept = findViewById(R.id.buttonSelectDept);
        buttonCancel = findViewById(R.id.buttonCancel);


        buttonSelectDept.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                i = radioGroupCourse.getCheckedRadioButtonId();
                Intent intent = new Intent();

                if ( i == R.id.radioButtonComputer){
                    intent.putExtra(KEY,getString(R.string.computerScience));
                    setResult(RESULT_OK,intent);
                    finish();
                }else if ( i == R.id.radioButtonSoftware){
                    intent.putExtra(KEY,getString(R.string.Software));
                    setResult(RESULT_OK,intent);
                    finish();
                }else if ( i == R.id.radioButtonData){
                    intent.putExtra(KEY,getString(R.string.dataScience));
                    setResult(RESULT_OK,intent);
                    finish();
                }else if ( i == R.id.radioButtonBio){
                    intent.putExtra(KEY,getString(R.string.BioInfo));
                    setResult(RESULT_OK,intent);
                    finish();
                }


            }
        });

        buttonCancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                setResult(RESULT_CANCELED);
                finish();
            }
        });




    }
}
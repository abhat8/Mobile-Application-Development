package com.example.hw2;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class UserRCVAdapter extends RecyclerView.Adapter<UserRCVAdapter.UserViewHolder> {

    ArrayList<DataServices.User> users;

    //custom Const.
    public UserRCVAdapter(ArrayList<DataServices.User> data){
        this.users = data;
    }

    @NonNull
    @Override
    public UserViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        //inflate own view
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.custom_layout,parent,false);
        //We need to return a viewHolder not a view so
        UserViewHolder userViewHolder = new UserViewHolder(view);

        return userViewHolder;
    }

    @Override
    public void onBindViewHolder(@NonNull UserViewHolder holder, int position) {

        DataServices.User user = users.get(position);
        View view = holder.rootView;
        //we have holder from UserViewHolder
        holder.name.setText(user.name);
        holder.state.setText(user.state);
        holder.age.setText(user.age+" "+ view.getContext().getString(R.string.yrs));
        holder.group.setText(user.group);
        if(user.gender == "Male"){
            holder.imageView.setImageResource(R.drawable.avatar_male);
        }else {
            holder.imageView.setImageResource(R.drawable.avatar_female);
        }


    }

    @Override
    public int getItemCount() {
        return this.users.size();
    }

    public class UserViewHolder extends RecyclerView.ViewHolder{
        //here we setup our view
        //give references to TextView and so on
        TextView name;
        TextView state;
        TextView age;
        TextView group;
        ImageView imageView;
        View rootView;

        public UserViewHolder(@NonNull View itemView) {
            super(itemView);
            //this references will be stored
            rootView = itemView;
            name = itemView.findViewById(R.id.name);
            state = itemView.findViewById(R.id.state);
            age = itemView.findViewById(R.id.age);
            group = itemView.findViewById(R.id.group);
            imageView = itemView.findViewById(R.id.imageView);
        }
    }

}

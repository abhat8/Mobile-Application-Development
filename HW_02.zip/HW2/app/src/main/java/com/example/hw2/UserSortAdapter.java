package com.example.hw2;

import android.annotation.SuppressLint;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class UserSortAdapter extends RecyclerView.Adapter<UserSortAdapter.userViewHolder1> {


    ArrayList<String> data;
    SortFragment.UserSortInterface mListner;

    //custom Const.
    public UserSortAdapter(ArrayList<String> data, SortFragment.UserSortInterface mListner){
        this.data = data;
        this.mListner=mListner;
    }

    @NonNull
    @Override
    public userViewHolder1 onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {

        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.custom_sort,parent,false);
        userViewHolder1 userViewHolder1= new userViewHolder1(view);

        return userViewHolder1;
    }

    @Override
    public void onBindViewHolder(@NonNull userViewHolder1 holder, @SuppressLint("RecyclerView") int position) {

        holder.tv.setText(data.get(position));
        holder.imageView1.setImageResource(R.drawable.ic_sort_ascending);
        holder.imageView2.setImageResource(R.drawable.ic_sort_descending);

        holder.imageView1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                mListner.sendSortData(data.get(position),true);

            }
        });

        holder.imageView2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                mListner.sendSortData(data.get(position),false);

            }
        });

    }

    @Override
    public int getItemCount() {
        return this.data.size();
    }

    public class userViewHolder1 extends RecyclerView.ViewHolder{

        TextView tv;
        ImageView imageView1;
        ImageView imageView2;

        public userViewHolder1(@NonNull View itemView) {
            super(itemView);
            tv = itemView.findViewById(R.id.textView);
            imageView1 = itemView.findViewById(R.id.imageView2);
            imageView2 = itemView.findViewById(R.id.imageView3);
        }
    }







}

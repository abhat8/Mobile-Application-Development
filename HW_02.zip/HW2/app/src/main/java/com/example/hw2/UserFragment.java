package com.example.hw2;

import android.content.Context;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;


public class UserFragment extends Fragment {

    RecyclerView recyclerView;
    RecyclerView.LayoutManager layoutManager;
    UserRCVAdapter adapter;
    ArrayList<DataServices.User> users;
    ArrayList<DataServices.User> temp ;


    private static final String ARG_PARAM1 = "param1";

    private String mParam1;

    public UserFragment() {
        // Required empty public constructor
    }


    public static UserFragment newInstance(String param1) {
        UserFragment fragment = new UserFragment();
        Bundle args = new Bundle();
        args.putString(ARG_PARAM1, param1);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mParam1 = getArguments().getString(ARG_PARAM1);
        }
        users = DataServices.getAllUsers();
        temp = (ArrayList<DataServices.User>) users.clone();
        adapter = new UserRCVAdapter(temp);
    }



    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        // Inflate the layout for this fragment
        View v =  inflater.inflate(R.layout.fragment_user, container, false);
        getActivity().setTitle(getString(R.string.user));

        //recycler View setup
        recyclerView = v.findViewById(R.id.rc);
        recyclerView.setHasFixedSize(true);
        layoutManager = new LinearLayoutManager(v.getContext());
        recyclerView.setLayoutManager(layoutManager);



        //Define Adapter
        recyclerView.setAdapter(adapter);

        v.findViewById(R.id.filter).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                mListner.sendData(users);

            }
        });

        v.findViewById(R.id.sort).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                mListner.sendToSort();
            }
        });




        return v;
    }


    public void updateList(String state, String sortProperty, Boolean ascending){

        temp.clear();
        String as = getString(R.string.allStates);

        if ( state == null){
            state = getString(R.string.allStates);
        }

        if(state.contentEquals(as)){
            temp.addAll(users);
        }else {
            for (int i = 0; i < users.size(); i++) {
                if (users.get(i).state.contentEquals(state)){
                    temp.add(users.get(i));
                }

            }
        }



        if (sortProperty == null){

        }else {
            Collections.sort(temp, new Comparator<DataServices.User>() {
                @Override
                public int compare(DataServices.User user, DataServices.User t1) {
                    if (sortProperty.contentEquals(getString(R.string.age))){
                        if (ascending){
                            return user.age - t1.age;
                        }
                        else return t1.age - user.age;
                    }else if(sortProperty.contentEquals(getString(R.string.name))){

                        if (ascending){
                            return user.name.compareTo(t1.name);
                        }
                        else return t1.name.compareTo(user.name);

                    }else if(sortProperty.contentEquals(getString(R.string.state))){

                        if (ascending){
                            return user.state.compareTo(t1.state);
                        }
                        else return t1.state.compareTo(user.state);

                    }

                    return 0;
                }
            });
        }




        adapter.notifyDataSetChanged();


    }



    @Override
    public void onAttach(@NonNull Context context) {
        if (context instanceof userInterface){
            mListner = (userInterface) context;
        }
        super.onAttach(context);

    }

    userInterface mListner;

    interface userInterface{
        public void sendData(ArrayList<DataServices.User> user);
        public void sendToSort();
    }

}
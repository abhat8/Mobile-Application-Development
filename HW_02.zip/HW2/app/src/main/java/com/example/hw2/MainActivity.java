package com.example.hw2;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;

import android.os.Bundle;
import android.widget.ImageView;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity implements UserFragment.userInterface,FilterFragment.filterInterface,SortFragment.UserSortInterface{

    private UserFragment userFragment;
    private String selectedState, selectedSortProperty;
    private Boolean ascending;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        userFragment = new UserFragment();
        getSupportFragmentManager().beginTransaction()
                .add(R.id.rootView, userFragment)
                .addToBackStack(null)
                .commit();

    }

    @Override
    public void sendData(ArrayList<DataServices.User> user) {
        getSupportFragmentManager().beginTransaction()
                .replace(R.id.rootView, FilterFragment.newInstance(user))
                .addToBackStack(null)
                .commit();
    }

    @Override
    public void sendToSort() {
        getSupportFragmentManager().beginTransaction()
                .replace(R.id.rootView, new SortFragment())
                .addToBackStack(null)
                .commit();
    }

    @Override
    public void sendState(String state) {
        selectedState = state;
        userFragment.updateList(state, selectedSortProperty, ascending);
        getSupportFragmentManager().popBackStack();
    }

    public void sendSortData(String property, Boolean asc) {
        selectedSortProperty = property;
        ascending = asc;
        userFragment.updateList(selectedState, selectedSortProperty, ascending);
        getSupportFragmentManager().popBackStack();
    }
}
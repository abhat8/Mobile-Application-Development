package com.example.hw2;

import android.content.Context;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import java.util.ArrayList;

public class SortFragment extends Fragment {


    RecyclerView recyclerView;
    RecyclerView.LayoutManager layoutManager;
    UserSortAdapter adapter;
    ArrayList<String> data = new ArrayList<>();

    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";

    private String mParam1;
    private String mParam2;

    public SortFragment() {
        // Required empty public constructor
    }

    public static SortFragment newInstance(String param1, String param2) {
        SortFragment fragment = new SortFragment();
        Bundle args = new Bundle();
        args.putString(ARG_PARAM1, param1);
        args.putString(ARG_PARAM2, param2);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mParam1 = getArguments().getString(ARG_PARAM1);
            mParam2 = getArguments().getString(ARG_PARAM2);
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View v= inflater.inflate(R.layout.fragment_sort, container, false);

        //recycler View setup
        recyclerView = v.findViewById(R.id.rc2);
        recyclerView.setHasFixedSize(true);
        layoutManager = new LinearLayoutManager(v.getContext());
        recyclerView.setLayoutManager(layoutManager);
        data.add(getString(R.string.age));
        data.add(getString(R.string.name));
        data.add(getString(R.string.state));

        //Define Adapter
        adapter = new UserSortAdapter(data,mListner);
        recyclerView.setAdapter(adapter);





        return v;
    }

    @Override
    public void onAttach(@NonNull Context context) {
        if (context instanceof UserSortInterface){
            mListner= (UserSortInterface) context;
        }
        super.onAttach(context);
    }

    UserSortInterface mListner;

    interface UserSortInterface{
        public void sendSortData(String sortBy, Boolean order);
    }
}
package com.example.hw2;

import android.content.Context;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;


public class FilterFragment extends Fragment {

    ArrayList<String> states = new ArrayList<>() ;
    ListView listView;
    ArrayAdapter<String> adapter;

    private static final String ARG_PARAM1 = "param1";

    private ArrayList<DataServices.User> mParam1;


    public FilterFragment() {
        // Required empty public constructor
    }

    public static FilterFragment newInstance(ArrayList<DataServices.User> param1) {
        FilterFragment fragment = new FilterFragment();
        Bundle args = new Bundle();
        args.putSerializable(ARG_PARAM1, param1);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            this.mParam1 = (ArrayList<DataServices.User>) getArguments().getSerializable(ARG_PARAM1);

        }



    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        getActivity().setTitle(getString(R.string.filterS));


        // Inflate the layout for this fragment
        View v = inflater.inflate(R.layout.fragment_filter, container, false);

        makeList();

        //listview

        listView = v.findViewById(R.id.listView);
        adapter = new ArrayAdapter<>(v.getContext(), android.R.layout.simple_list_item_1, android.R.id.text1,states);
        listView.setAdapter(adapter);


        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {

                String selectedState = states.get(i);

                mListner.sendState(selectedState);
            }
        });


                return v;
    }

    @Override
    public void onAttach(@NonNull Context context) {
        if(context instanceof filterInterface){
            mListner = (filterInterface) context;
        }
        super.onAttach(context);
    }

    filterInterface mListner;


    private void makeList(){

        for (int i=0; i<mParam1.size(); i++){
            String temp = mParam1.get(i).state;
            if(this.states.contains(temp)){

            }else {
                this.states.add(temp);
            }
        }

        Collections.sort(states);
        this.states.add(0,getString(R.string.allStates));

    }

    interface filterInterface{
        public void sendState(String state);
    }

}

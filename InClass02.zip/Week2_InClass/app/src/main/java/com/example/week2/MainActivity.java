package com.example.week2;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import java.util.concurrent.BlockingDeque;

public class MainActivity extends AppCompatActivity {
    RadioGroup radioGroup;
    TextView input;




    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        radioGroup = findViewById(R.id.radioGroup);
        input = findViewById(R.id.textViewEnterPrice);


        Button buttonCalculate = findViewById(R.id.buttonCalculate);
        TextView tRes = findViewById(R.id.textViewResult);

        buttonCalculate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                try {

                    Log.d("De", "onClick:Calculte pressed ");
                    int cId = radioGroup.getCheckedRadioButtonId();
                    Log.d("De", "onClick:Calculte pressed "+ cId);

                    if (cId == R.id.rBt5) {
                        float price = Float.parseFloat(String.valueOf(input.getText()));
                        float t = (float) (price * 0.05);
                        price = price - t;
                        tRes.setText(String.valueOf(price));
                    } else if (cId == R.id.rBt10) {
                        float price = Float.parseFloat(String.valueOf(input.getText()));
                        float t = (float) (price * 0.10);
                        price = price - t;
                        tRes.setText(String.valueOf(price));
                    } else if (cId == R.id.rBt15) {
                        float price = Float.parseFloat(String.valueOf(input.getText()));
                        float t = (float) (price * 0.15);
                        price = price - t;
                        tRes.setText(String.valueOf(price));
                    } else if (cId == R.id.rBt20) {
                        float price = Float.parseFloat(String.valueOf(input.getText()));
                        float t = (float) (price * 0.20);
                        price = price - t;
                        tRes.setText(String.valueOf(price));
                    } else if (cId == R.id.rBt50) {
                        float price = Float.parseFloat(String.valueOf(input.getText()));
                        float t = (float) (price * 0.5);
                        price = price - t;
                        tRes.setText(String.valueOf(price));
                    }
                }catch (NumberFormatException e){
                    Log.d("De", "onClick: Error caught ");
                    Toast.makeText(MainActivity.this, "Null value", Toast.LENGTH_LONG).show();
                }


            }
        });
        Button clrBt = findViewById(R.id.button2);
        clrBt.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                tRes.setText("");
                input.setText("");
                radioGroup.clearCheck();
            }
        });
    }
}
